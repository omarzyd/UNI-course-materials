Study Hub kit
1. Install: Python 3 + `pip install pillow pypdfium2 pypdf`, and Chrome or Edge.
2. Open Claude Code inside this folder.
3. Paste the part of PROMPT.md below the line as your first message.
4. When Claude says "Got it", ask: "build <course> lecture <n>" and give it the path to your course files.
Quick test:  python build_hub.py && python tools/check_all.py
